from .mssh_menu import main

main()
